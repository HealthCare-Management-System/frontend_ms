import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient-visit-info-list',
  templateUrl: './patient-visit-info-list.component.html',
  styleUrls: ['./patient-visit-info-list.component.css']
})
export class PatientVisitInfoListComponent implements OnInit {

  
  @Input()
  dataSource!: any;
  @Input()
  patientInfoId!:any;
  @Input()
  displayedColumns: string[] = ['PatientName', 'PhysicianName', 'VisitDate', 'Procedures','Medication','view'];
  constructor(public router:Router) { }

  ngOnInit(): void {
  }
  getPatientVisitinfo(id:number){
    // this.patientInfoId=element.vitalSignId.patientInfoId.
//send the elementobject to the component
this.router.navigate(['admin/dashboard/patient-visit-info'], { queryParams: { meetingid: id} });

  }
}
